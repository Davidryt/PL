#include <stdio.h>
 
main () 
{
	puts ("El texto se imprime ") ;
}

//@ (main)

