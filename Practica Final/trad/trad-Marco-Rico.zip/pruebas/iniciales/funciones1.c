#include <stdio.h>


mifuncion () 
{
    puts ("Una prueba") ;
}


main ()
{
     mifuncion () ;
     
//     system ("pause") ;
}

//@ (main)
