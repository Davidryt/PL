#include <stdio.h>


cuadrado (int n) 
{
	printf ("cuadrado de n %d %d", n, n*n) ;
	puts ("") ;
}


main ()
{
     cuadrado (4) ;
     cuadrado (10) ;
          
//     system ("pause") ;
}

//@ (main)
