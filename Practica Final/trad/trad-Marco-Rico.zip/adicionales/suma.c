#include <stdio.h>
main() {
  int a = 5, b = 10;
  int resultado;
  resultado = a + b;
  printf("%d\n", resultado);
}

//@ (main) 
