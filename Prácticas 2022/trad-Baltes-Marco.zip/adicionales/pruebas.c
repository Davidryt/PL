////////////////////////Prueba variable main
int a = 3;
int b;

int z = 1, pepe, patata = 38, puerro=2;
int z = 1, pepe, patata = 38;
main (){
    int c = 3;
    int d;
    int a = 1;
    int b = 0;
    c = 1+2;
    d = 4;  
    for(c=1; 1==1; c = c + 1){
        int a=1;
    }
    //int max = (a>b) ? a : b;
    puts("-----------------------------------------------------------------------------------------------------------------------------------");
}

////////////////////////Prueba funcion main
func (int a, int b, int c = 1, int d){
    int a = 3;
    int b;
    b = 4;
    a = 1+2;
    int z = 1, pepe, patata = 38;
    printf(1+1);
    printf("Cebolla",1+1,1+2);
    puts("Hola mundo");
     while (a == 2){
        int z = 1, pepe, patata = 38;
        printf(1+1);
        printf("Cebolla",1+1,1+2);
        puts("Hola mundo");
    }
    if(b>=2)
    {
        int z = 1, pepe, patata = 38;
        printf(1+1);
        printf("Cebolla",1+1,1+2);
        puts("Hola mundo");
    }
}
main (){
    int a = 3;
    int b;
    b = 4;
    a = 1+2; 
    int z = 1, pepe, patata = 38; 
    printf(1+1);
    printf("Cebolla",1+1,1+2);
    puts("Hola mundo");
    while (a != 2){
        int z = 1, pepe, patata = 38;
        printf(1+1);
        printf("Cebolla",1+1,1+2);
        puts("Hola mundo");
    }
    if(b>=2)
    {
        int z = 1, pepe, patata = 38;
        printf(1+1);
        printf("Cebolla",1+1,1+2);
        puts("Hola mundo");
        for(c=1; 1==1; c = c + 1){
            int a=1;
        }
    }
    puts("-----------------------------------------------------------------------------------------------------------------------------------");
}

////////////////////////Prueba completo
int a = 3;
int b;

int c[5];

int z = 1, pepe, patata = 38;
func (int a, int b, int c=2){            // Error aquii
    int a = 3;
    int b;
    b = 4;
    a = 1+2;
    int z = 1, pepe, patata = 38;
    printf(1+1);
    printf("%d",1+1,1+2);   
    puts("Hola mundo"); 
    while(b <= 2){
        int z = 1, pepe, patata = 38;
        printf(1+1);
        printf("Cebolla",1+1,1+2);
        puts("Hola mundo");
    }
    if(b>=2 || 1==1 && 1 != 2)
    {
        int z = 1, pepe, patata = 38;
        printf(1+1);
        printf("Cebolla",1+1,1+2);
        puts("Hola mundo");
    }
    for(c=1; 1==1; c = c + 1){
        int a=1;
    }
}
main (){
    int a = 3;
    int b;
    b = 4;
    a = 1+2;
    int z = 1, pepe, patata = 38;
    printf(1+1);
    printf("Cebolla",1+1,1+2);
    puts("Hola mundo");
    while (a == 2){
        int z = 1, pepe, patata = 38;
        printf(1+1);
        printf("Cebolla",1+1,1+2);
        puts("Hola mundo");
    }
    while (a>2){
        puts("Hola mundo");
    }
    while (a<2){
        puts("Hola mundo");
    }
    if(b>=2)
    {
        int z = 1, pepe, patata = 38;
        printf(1+1);
        printf("Cebolla",1+1,1+2);
        puts("Hola mundo");
    } else{
        int z = 1, pepe, patata = 38;
        printf(1+1);
        printf("Cebolla",1+1,1+2);
        puts("Hola mundo");

    }
    for(c=1; 1==1; c = c + 1){
        int a=1;
    }
    puts("-----------------------------------------------------------------------------------------------------------------------------------");
}
////////////////////////Cómo ejecutar
// cat pruebas.c | ./a.out